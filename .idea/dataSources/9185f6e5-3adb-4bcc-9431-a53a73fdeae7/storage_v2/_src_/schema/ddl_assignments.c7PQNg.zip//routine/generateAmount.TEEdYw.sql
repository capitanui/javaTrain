create
    definer = root@localhost procedure generateAmount(OUT generated_amount decimal(50, 10))
begin
    declare generated_amount decimal(50, 10);
    set generated_amount = rand() * 1000 + rand() * 100;
end;

