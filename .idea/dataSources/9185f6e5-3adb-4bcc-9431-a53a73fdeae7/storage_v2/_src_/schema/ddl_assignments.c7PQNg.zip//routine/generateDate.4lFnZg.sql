create
    definer = root@localhost procedure generateDate(OUT date_ datetime)
begin
    set date_ = from_unixtime(
                unix_timestamp('2000-1-1') + floor(
                        rand() * (
                        unix_timestamp('2010-12-31') - unix_timestamp('2000-1-1') + 1
                        )
                )
        );
end;

