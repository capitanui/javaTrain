create
    definer = root@localhost procedure insertInstallmentsPerLoanAccount(IN account_id varchar(256),
                                                                        IN amount decimal(50, 10),
                                                                        IN creation_date datetime,
                                                                        IN number_of_installments int(4))
begin
end;

