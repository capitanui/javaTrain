create
    definer = root@localhost procedure generateNumberOfInstallments(IN type varchar(256), OUT number_of_installments int(4))
begin
    if (type = 'Fixed') then
        set number_of_installments = 12;
    end if;
    if (type = 'Revolving') then
        set number_of_installments = 1;
    end if;
    if (type = 'Dynamic') then
        set number_of_installments = floor((RAND() * 13));
    end if;
end;

