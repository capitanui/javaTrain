create
    definer = root@localhost function randAccountType() returns varchar(15)
BEGIN
    DECLARE randGen INT;
	SET randGen = floor(rand()*10);
		IF randGen < 3 THEN RETURN 'DYNAMIC';
          ELSEIF randGen >= 3 AND randGen < 7 THEN RETURN 'FIXED';
		  ELSE return 'REVOLVING';
		END IF;
END;

