create
    definer = root@localhost procedure insertLoanAccounts()
begin
    declare insertion_encoded_key varchar(256);
    declare insertion_amount decimal(50, 10);
    declare insertion_type varchar(20);
    declare insertion_number_of_installments int(4);
    declare insertion_creation_date datetime;
    declare counter int;
    declare indexx int;
    set counter = 0;
    repeat
        set indexx = counter + 1;
        call generateUnique(insertion_encoded_key);
        call generateAmount(insertion_amount);
        call randomAssignLoanAccountType(insertion_type);
        call generateNumberOfInstallments(insertion_type, insertion_number_of_installments);
        call generateDate(insertion_creation_date);

#         insert into assignment_1.loan_account(encoded_key, type, amount, number_of_installments, creation_date)
#         VALUES (insertion_encoded_key, insertion_type, insertion_amount, insertion_number_of_installments,
#                 insertion_creation_date);
#
#         call insertInstallmentsPerLoanAccount(insertion_encoded_key, insertion_amount, insertion_creation_date,
#                                               insertion_number_of_installments);
        set counter = indexx;
    until counter = 15 end repeat;
end;

