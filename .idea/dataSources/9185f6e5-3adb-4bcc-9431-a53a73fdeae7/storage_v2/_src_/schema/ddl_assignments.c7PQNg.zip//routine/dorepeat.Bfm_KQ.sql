create
    definer = root@localhost procedure dorepeat(IN p1 int)
BEGIN
  SET @x = 0;
  REPEAT SET @x = @x + 1; UNTIL @x > p1 END REPEAT;
END;

