create
    definer = root@localhost procedure randomAssignLoanAccountType(OUT type varchar(20))
begin
    declare random decimal(10, 10);
    set random = RAND();
    if (random < 0.33) then
        set type = 'Dynamic';
    end if;
    if (random > 0.33 and random < 0.66) then
        set type = 'Fixed';
    end if;
    if (random > 0.66) then
        set type = 'Revolving';
    end if;
end;

