create
    definer = root@localhost procedure generateDateAfter(IN before_date datetime, OUT after_date datetime)
begin
end;

