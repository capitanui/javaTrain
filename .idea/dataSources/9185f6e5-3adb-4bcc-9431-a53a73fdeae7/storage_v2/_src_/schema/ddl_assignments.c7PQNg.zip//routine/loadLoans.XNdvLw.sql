create
    definer = root@localhost procedure loadLoans(IN nr_loans int, OUT result varchar(100))
BEGIN
		IF nr_loans <= 0 THEN
			SET result = 'Invalid number of loans requested';
		ELSE
			BEGIN
                 DECLARE i INT;
				 DECLARE s INT;
				 DECLARE newAccountId INT;
				 DECLARE maxScheduleId INT;
				 DECLARE randAmount INT;
				 DECLARE randNrOfInstallments INT;
                 DECLARE dueDate DATE;
                 DECLARE principalDue Double;
				 DECLARE interestDue Double;
				 DECLARE balance Double;

                 set i=1;
						     WHILE i<nr_loans DO
                             	SELECT COALESCE(MAX(ID),0)+1 INTO newAccountId FROM LOANACCOUNT;
								SELECT COALESCE(MAX(ID),0)+1 INTO maxScheduleId FROM SCHEDULE;
                                
								SET randAmount = FLOOR(RAND()*10000)+FLOOR(RAND()*100);
                                SET randNrOfInstallments = RAND()*10+2;
                                SET balance=randAmount;
									START TRANSACTION;
              							 INSERT INTO LOANACCOUNT ( ID, CREATIONDATE, TYPE, AMOUNT, NROFINSTALMENTS)
              							 VALUES (newAccountId, NOW(), randAccountType(), randAmount, randNrOfInstallments);
                                         set s=randNrOfInstallments;
									     create_schedule: REPEAT
											 IF s=randNrOfInstallments THEN set dueDate=date(last_day(now()));
                                                else set dueDate = LAST_DAY(DATE_ADD(now(),INTERVAL randNrOfInstallments-s MONTH));
											 END IF;
                                             
                                             set principalDue = randAmount DIV randNrOfInstallments;
											 set interestDue = (principalDue * 0.06);
											 set balance =  balance - principalDue;
                                             
                                             INSERT INTO SCHEDULE values (maxScheduleId,newAccountId,dueDate,principalDue,0,interestDue,0,0,0,0,0,balance,'ACTIVE');
                                             set s=s-1;
                                             set maxScheduleId=maxScheduleId+1;
 										 UNTIL s=0
									     END  REPEAT create_schedule;
									COMMIT;
                                    
                               set i=i+1;
                             END WHILE;
                   set result= CONCAT(nr_loans,' were created succesfully');
               END;
        END IF;
   END;

