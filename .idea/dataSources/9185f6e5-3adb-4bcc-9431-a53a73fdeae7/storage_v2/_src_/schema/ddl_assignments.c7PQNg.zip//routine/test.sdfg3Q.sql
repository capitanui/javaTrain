create
    definer = root@localhost procedure test(INOUT nr_loans int)
progr: BEGIN
      set nr_loans=4;
      LEAVE progr;
      set nr_loans=10;
   END progr;

