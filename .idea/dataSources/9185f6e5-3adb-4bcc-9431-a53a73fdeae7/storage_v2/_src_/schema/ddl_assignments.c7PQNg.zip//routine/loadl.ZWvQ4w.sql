create
    definer = root@localhost procedure loadl(INOUT nr_loans int)
BEGIN
      set nr_loans=4;
   END;

